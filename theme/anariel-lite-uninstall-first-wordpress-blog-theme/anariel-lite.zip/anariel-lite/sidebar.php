<?php if(is_active_sidebar( 'anariel_sidebar' )) { ?>
	<div class="sidebar">	
		<?php dynamic_sidebar( 'anariel_sidebar' ); ?>
	</div>
<?php } ?>
