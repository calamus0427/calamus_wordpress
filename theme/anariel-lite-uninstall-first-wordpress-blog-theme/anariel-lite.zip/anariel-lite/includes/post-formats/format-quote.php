<div class="blogpostcategory">	
	<div class="entry">
		<div class = "meta">
			<div class="blogContent">
				<div class="blogcontent"><?php the_content(esc_html__('','anariel')) ?> </div>
			</div>
			<div class="blogcontent-title"><?php the_title() ?> </div>
		</div>		
	</div>	
</div>
	