<?php

defined('WYSIJA') or die('Restricted access');

class WYSIJA_model_statistics extends WYSIJA_model{
    public $countRows = 0;   
}
